<!DOCTYPE html>
<html lang="en">
<head>

   <title>Black Friday</title>
  <meta charset="utf-8">
  <link rel="stylesheet" type="text/css" href="../../css/style.css" />
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
  <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.6.3/css/all.css" integrity="sha384-UHRtZLI+pbxtHCWp1t77Bi1L4ZtiqrqD80Kn4Z8NTSRyMA2Fd33n5dQ8lWUE00s/" crossorigin="anonymous"></head>

<style>
.cut img {
max-width:20%;
height: auto;
max-height:100%;
padding:20px;
margin:50px;

}
.head{
	background-color:#1C2833;
	color:white;
	width:100%;
	padding:0px;
	height:50px;
	text-align:center;
	
}
* {
  margin: 0px;
  padding: 0px;
}
body {
  font-size: 120%;
  background: #F8F8FF;
}

.header{
  width:100%;
  /*margin: 50px auto 0px;*/
  color: white;
 /* background-color:#5F9EA0;*/
  background-color:#1C2833;
  text-align:center;
  border: 1px solid #B0C4DE;
  border-bottom: none;
  border-radius: 10px 10px 0px 0px;
  padding: 20px;
}
form, .content {
  margin: 0px auto;
  width:100%;
  padding: 20px;
  border: 1px solid #B0C4DE;
  background: white;
  border-radius: 0px 0px 10px 10px;
}
.input-group {
  margin: 10px 0px 10px 0px;
}
.input-group label {
  display: block;
  text-align: left;
  margin: 5px;
}
.input-group input {
  height:40px;
  width: 100%;
  padding: 5px 10px;
  font-size: 16px;
  border-radius: 5px;
  border: 1px solid gray;
}
.btn {
  padding: 8px;
  font-size:16px;
  color:white;
  background:#1C2833;
  border: none;
  border-radius: 5px;
}
.error {
  width: 92%; 
  margin: 0px auto; 
  padding: 10px; 
  border: 1px solid #a94442; 
  color: #a94442; 
  background: #f2dede;
  border-radius: 5px; 
  text-align: left;
}
.success {
  color: #3c763d; 
  background: #dff0d8; 
  border: 1px solid #3c763d;
  margin-bottom: 20px;
}
  header { 

  background: url(../../img/ktm1.jpg)no-repeat center fixed; 
  height:360px;
  width:100%;
}
body {
    font-family: Arial;
    line-height: 30px;
    color: #333;
}

#payment-box {
    padding: 40px;
    margin: 20px;
    border: #E4E4E4 1px solid;
    display: inline-block;
    text-align: center;
    border-radius: 3px;
}

#pay_now {
    padding: 10px 30px;
    background: #09f;
    border: #038fec 1px solid;
    border-radius: 3px;
    color: #FFF;
    width: 100%;
    cursor: pointer;
}

.txt-title {
    margin: 25px 0px 0px 0px;
    color: #4e4e4e;
}

.txt-price {
    margin-bottom: 20px;
    color: #08926c;
    font-size: 1.1em;
}
</style>

</head>

<body>
<div class="container">
<div class="row">
 <div class="col-sm-12">
<header class="title">
<div class="cut">
<img src="../../img/icon.jpg"alt="">
</div>
</header>
</div>
</div>
</div>
<div class="container" >
<div class="row">
 <div class="col-sm-12">
<nav class="navbar navbar-expand-sm bg-dark navbar-dark">
  <!-- Brand/logo -->
  <a class="navbar-brand" href="#">
    <img src="../../img/logo.jpg" alt="logo" style="width:40px;">
  </a>
  
  <!-- Links -->
  <ul class="navbar-nav">
    <li class="nav-item">
      <a class="nav-link" href="../../home.php"><b>Home</b></a>
    </li>
    <li class="nav-item">
      <a class="nav-link" href="#"><b>Cart</b></a>
    </li>
    <li class="nav-item">
      <a class="nav-link" href="../../checkout.php"><b>Checkout</b></a>
    </li>
	    <li class="nav-item">
      <a class="nav-link" href="../../index.php"><b>My account</b></a>
    </li>
	    <li class="nav-item">
      <a class="nav-link" href="#"><b>Shop</b></a>
    </li>
	    <li class="nav-item">
      <a class="nav-link" href="../../register.php"><b>Sign Up</b></a>
    </li>
	  <li class="nav-item">
      <a class="nav-link" href="../../login.php"><b>Sign In</b></a>
    </li>
			  <li class="nav-item">
      <a class="nav-link" href="../../index.php?logout='1'"><b>Sign out</b></a>
    </li>
	<li class="nav-item dropdown">
      <a class="nav-link dropdown-toggle" href="#" id="navbardrop" data-toggle="dropdown">
       <b> Brands</b>
      </a>
      <div class="dropdown-menu">
        <a class="dropdown-item" href="../../honda.php"><b>Honda</b></a>
        <a class="dropdown-item" href="../../yamaha.php"><b>yamaha</b></a>
        <a class="dropdown-item" href="../../suzuki.php"><b>Suzuki</b></a>
		<a class="dropdown-item" href="../../aprilia.php"><b>Aprilia<b></a>
		<a class="dropdown-item" href="../../ktm.php"><b>KTM</b></a>
		</div>

  </ul>

</nav>
</div>
</div>

</div>
<div class="container">
  <div class="row">
    <div class="col-sm-12">    
	    <div id="payment-box">

<div class="header">
  	<h2>Payment Method</h2>
  </div>
    <form class="input-group" id="sform" onsubmit=" return formvali();" action="../model/insert.php" method="POST">
Name: <input type="text" id="name" name="name" placeholder="Your nmae"><br>
Phone: <input type="number" id="phone" name="phone" placeholder="Your phone number"><br>

User name : <input type="text" id="uname" name="uname" placeholder="Your user name .."><br>

Bick model: <input type="text" id="model" name="model" placeholder="Bick model"><br>
Bick price: <input type="text" id="price" name="price" placeholder="Bick price"><br>
Currency: <input type="text" id="price" name="price" placeholder="Currency"><br>
Date: <input type="date" id="date" name="date" placeholder="Date"><br>
<br/>  
<input type="submit"class="btn btn-success" value="Buy Now"><br>
</form>
</div>

    </div>     
</div>
</div>
</body>
</html>