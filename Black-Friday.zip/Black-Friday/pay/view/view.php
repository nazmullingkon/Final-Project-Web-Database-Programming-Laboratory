<P> <a href="../controller/logout.php"> Logout</a></P>
<?php
include("../controller/config.php");
include("../controller/session.php");
$sql="SELECT * FROM cuinfo";
$resultview=mysqli_query($myconn,$sql);
echo'<table border="2px"><tr> 
<th>Cu id</th> <th>name</th><th>Phone</th> <th>Username</th><th>Model</th><th>Price</th><th>Currency</th><th>Date</th> </tr>';
while($row=mysqli_fetch_array($resultview))
{
	$cuid=$row['cuid'];
	$name=$row['name'];
	$phone=$row['phone'];
	$uname=$row['uname'];
	$model=$row['model'];
	$price=$row['price'];
$currency=$row['currency'];
$date=$row['date'];
	echo '<tr><td>'.$cuid.'</td><td>'.$name.'</td><td>'.$phone.'</td><td>'.$uname.'</td><td>'.$model.'</td><td>'.$price.'</td><td>'.$currency.'</td> <td>'.$date.'</td></tr>';
}

?>