<?php
include("../controller/config.php");

$name=$_POST['name'];
$phone=$_POST['phone'];
$uname=$_POST['uname'];
$model=$_POST['model'];
$price=$_POST['price'];
$currency=$_POST['currency'];
$date=$_POST['date'];
$sql="INSERT INTO cuinfo(name, phone, uname,model,price,currency,date) VALUES('$name','$phone','$uname','$model','$price','$currency','date')";
$result=mysqli_query($myconn,$sql);
if($result===TRUE)
{
	header("location:../view/view.php");
}
else
{
	echo "registration fail";
	}

?>
