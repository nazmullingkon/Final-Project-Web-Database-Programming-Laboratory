<!DOCTYPE html>
<html lang="en">
<head>

   <title>Black Friday</title>
  <meta charset="utf-8">
  <link rel="stylesheet" type="text/css" href="css/style.css" />
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
  <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.6.3/css/all.css" integrity="sha384-UHRtZLI+pbxtHCWp1t77Bi1L4ZtiqrqD80Kn4Z8NTSRyMA2Fd33n5dQ8lWUE00s/" crossorigin="anonymous"></head>
  <link rel="stylesheet" type="text/css" href="style.css">
<style>
  header { 

  background: url(img/ktm1.jpg)no-repeat center fixed; 
  height:360px;
  width:100%;
}

table{border:5px solid black;background-color:#1C2833; color:white;width:100%;text-align:center;}
tr{border:5px solid black;}
td{border:5px solid black;}
th{border:5px solid black;}

</style>

</head>

<body>
<div class="container">
<div class="row">
 <div class="col-sm-12">
<header class="title">
<div class="cut">
<img src="img/icon.jpg"alt="">
</div>
</header>
</div>
</div>
</div>
<div class="container" >
<div class="row">
 <div class="col-sm-12">
<nav class="navbar navbar-expand-sm bg-dark navbar-dark">
  <!-- Brand/logo -->
  <a class="navbar-brand" href="#">
    <img src="img/logo.jpg" alt="logo" style="width:40px;">
  </a>
  
  <!-- Links -->
  <ul class="navbar-nav">
    <li class="nav-item">
      <a class="nav-link" href="home.php"><b>Home</b></a>
    </li>
    <li class="nav-item">
      <a class="nav-link" href="#"><b>Cart</b></a>
    </li>
    <li class="nav-item">
      <a class="nav-link" href="checkout.php"><b>Checkout</b></a>
    </li>
	    <li class="nav-item">
      <a class="nav-link" href="index.php"><b>My account</b></a>
    </li>
	    <li class="nav-item">
      <a class="nav-link" href="#"><b>Shop</b></a>
    </li>
	    <li class="nav-item">
      <a class="nav-link" href="register.php"><b>Sign Up</b></a>
    </li>
	  <li class="nav-item">
      <a class="nav-link" href="login.php"><b>Sign In</b></a>
    </li>
		  <li class="nav-item">
      <a class="nav-link" href="index.php?logout='1'"><b>Sign out</b></a>
    </li>
	<li class="nav-item dropdown">
      <a class="nav-link dropdown-toggle" href="#" id="navbardrop" data-toggle="dropdown">
       <b> Brands</b>
      </a>
      <div class="dropdown-menu">
        <a class="dropdown-item" href="honda.php"><b>Honda</b></a>
        <a class="dropdown-item" href="yamaha.php"><b>yamaha</b></a>
        <a class="dropdown-item" href="suzuki.php"><b>Suzuki</b></a>
		<a class="dropdown-item" href="aprilia"><b>Aprilia<b></a>
		<a class="dropdown-item" href="ktm"><b>KTM</b></a>
		</div>

  </ul>

</nav>
</div>
</div>

</div>

<br/>
<div class="container">
<div class="row">
<div class="col-sm-12">
<?php
include("server.php");
$sql="SELECT * FROM users";
$resultview=mysqli_query($db,$sql);
echo'<table>
<tr > 
<th>Id</th><th>Username</th><th>Email</th><th>Password</th><th> Edit</th> 
</tr>';
while($row=mysqli_fetch_array($resultview))
{
    $id=$row['id'];
	$username=$row['username'];
	$email=$row['email'];
	$pass=$row['password'];
	echo '<tr><td>'.$id.'</td><td>'.$username.'</td><td>'.$email.'</td><td>'.$pass.'</td><td><a href="updateform.php?id='.$id.'">Edit</a></td></tr>';
}

?>
</div>
<div>
</div>
</body>
</html>
