<!DOCTYPE html>
<html lang="en">
<head>

   <title>Black Friday</title>
  <meta charset="utf-8">
  <link rel="stylesheet" type="text/css" href="css/style.css" />
   <meta name="viewport" content="width=device-width, initial-scale=1">
   <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css"> 

  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
  <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.6.3/css/all.css" integrity="sha384-UHRtZLI+pbxtHCWp1t77Bi1L4ZtiqrqD80Kn4Z8NTSRyMA2Fd33n5dQ8lWUE00s/" crossorigin="anonymous"></head>
  <link rel="stylesheet" type="text/css" href="style.css">
<style>
  header { 

  background: url(img/ktm1.jpg)no-repeat center fixed; 
  height:360px;
  width:100%;
}
   .footer{background-color:#1C2833;
	color:white;
	width:100%;
	height:100px;
	border-radius: 0px 0px 10px 10px;
}
.con {
  position: relative;
  text-align: center;
  color: #D78D21;
}
.top-left {
  position: absolute;
  top: 8px;
  left: 16px;
}
</style>

</head>

<body>
<div class="container">
<div class="row">
 <div class="col-sm-12">
<header class="title">
<div class="cut">
<img src="img/icon.jpg"alt="">
</div>
</header>
</div>
</div>
</div>
<div class="container" >
<div class="row">
 <div class="col-sm-12">
<nav class="navbar navbar-expand-sm bg-dark navbar-dark">
 
  <a class="navbar-brand" href="#">
    <img src="img/logo.jpg" alt="logo" style="width:40px;">
  </a>
  
  <ul class="navbar-nav">
    <li class="nav-item">
      <a class="nav-link" href="home.php"><b>Home</b></a>
    </li>
    <li class="nav-item">
      <a class="nav-link" href="#"><b>Cart</b></a>
    </li>
    <li class="nav-item">
      <a class="nav-link" href="checkout.php"><b>Checkout</b></a>
    </li>
	    <li class="nav-item">
      <a class="nav-link" href="index.php"><b>My account</b></a>
    </li>
	    <li class="nav-item">
      <a class="nav-link" href="#"><b>Shop</b></a>
    </li>
	    <li class="nav-item">
      <a class="nav-link" href="register.php"><b>Sign Up</b></a>
    </li>
	  <li class="nav-item">
      <a class="nav-link" href="login.php"><b>Sign In</b></a>
    </li>
			  <li class="nav-item">
      <a class="nav-link" href="index.php?logout='1'"><b>Sign out</b></a>
    </li>
	<li class="nav-item dropdown">
      <a class="nav-link dropdown-toggle" href="#" id="navbardrop" data-toggle="dropdown">
       <b> Brands</b>
      </a>
      <div class="dropdown-menu">
        <a class="dropdown-item" href="honda.php"><b>Honda</b></a>
        <a class="dropdown-item" href="yamaha.php"><b>yamaha</b></a>
        <a class="dropdown-item" href="suzuki.php"><b>Suzuki</b></a>
		<a class="dropdown-item" href="aprilia"><b>Aprilia<b></a>
		<a class="dropdown-item" href="ktm"><b>KTM</b></a>
		</div>

  </ul>

</nav>
</div>
</div>

</div>

<br/>


<div class="container">
<div class="row">
 <div class="col-sm-12">



</div>
</div>
</div>
<br/>
  <h2 style="text-align:center;">YAMAHA MOTORCYCLES</h2><br/>
<div class="container">
  <div class="row">

  <div class="col-sm-3">
<img  class="img-fluid" src="img/Yamahaa.jpg" alt="HONDA"style="width:100%;height:160px;"><br><br>
<h4 style="background-color:#1C2833;color:white;">Brands</h4>
<a href="honda.php"><img  class="img-fluid" src="img/honda3.jpg" alt="honda3"style="width:45%;height:90px;"></a>
<a href="yamaha.php"><img  class="img-fluid" src="img/yamaha.jpg" alt="yamaha"style="width:45%;height:90px;"></a>
<a href="suzuki.php"><img  class="img-fluid" src="img/suzuki.jpg" alt="suzuki"style="width:45%;height:90px;"></a>
<a href="aprilia.php"><img  class="img-fluid" src="img/aprilia.jpg" alt="aprilia"style="width:45%;height:90px;"></a>
</div>
  <div class="col-sm-9">
<div class="head"style="background-color:#1C2833;">
<b>  <h3>SPECIFICATION OF YAMAHA R15 V3 DUAL ABS</h3></b><br/>
</div>
<div class="row">
    <div class="col-sm-4">
      <figure class="con">
<img src="img/Yamaha-R15.jpg" alt="Yamaha-R15"style="width:100%;height:160px;" />
<figcaption style="color:#1C2833;">YAMAHA R15 V3 DUAL ABS
Tk 485,000*</figcaption>
<a href="pay/view/addp.php" type="button" class="btn btn-success">Buy Now</a>  
</figure>
    </div>
    <div class="col-sm-8">
    <table class="table">

    <tbody>
      <tr>
        <th>Bike Name</th>
        <th>Yamaha R15 V3 Dual ABS</th>

      </tr>
      <tr>
        <th>Brand</th>
        <th>Yamaha</th>
      </tr>
	        </tr>
      <tr>
        <th>Bike Category</th>
        <th>Sports</th>
      </tr>
	        </tr>
      <tr>
        <th>Brand Origin</th>
        <th>Japan</th>
      </tr>
	        </tr>
      <tr>
        <th>Assemble/Made in</th>
        <th>India</th>
      </tr>
	        </tr>

    </tbody>
  </table>
  <h4>Engine</h4>
      <table class="table">

    <tbody>
<tr><th>Type</th>	<th>Liquid-cooled, 4-stroke, SOHC, 4-valve</th></tr></tr>
<tr><th>Displacement (cc)</th>	<th>155</th></tr></tr>
<tr><th>Max Power</th>	<th>19.3PS @ 10,000 rpm (Max Power Converter)</th></tr></tr>
<tr><th>Max Torque</th><th>	14.7N.m @ 8500 rpm (Max Torque Converter)</th></tr></tr>
<tr><th>Bore x Stroke</th><th>	58.0 X 58.7</th></tr></tr>
<tr><th>Carburettor</th><th>	Fuel Injection</th></tr></tr>
<tr><th>Starting Method</th><th>	Electric</th></tr></tr>
<tr><th>Ignition Type</th><th>	TCI</th></tr></tr>
<tr><th>Gears</th><th>	6</th></tr></tr>
<tr><th>Clutch</th><th>	Wet Multiple-disc</th></tr></tr>
<tr><th>Spark Plug</th><th>	NGK/MR8E9</th></tr></tr>

    </tbody>
  </table>

    </div>
  </div>



</div>
</div>
</div>
</div>
</div>
<div class="container">
<div class="row">
<div class="col-sm-12">
<div class="footer">
<ul class="list-group list-group-horizontal">

<li class="list-group-item"><a href="#"><p>Facebook</p></a></li>
<li class="list-group-item"><a href="#"><p>Twitter</p></a></li>

</ul>
</div>
</div>
</div>
</div>
<br/>
</body>
</html>
